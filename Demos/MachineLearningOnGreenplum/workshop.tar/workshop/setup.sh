#!/bin/bash

psql -f setup.psql

/usr/local/greenplum-db/madlib/bin/madpack install -s madlib -p greenplum -c gpadmin@mdw:5432/abalone
